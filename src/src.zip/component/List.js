import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { db } from './Instance';

function List() {
  const { category } = useParams();
  const [data, setData] = useState([]);

  useEffect(() => {
    (async function () {
      const fetchedData = await db.db_Movie(`/${category}/popular`);
      setData(fetchedData.data.results);
    })();
  }, [category]);

  return (
    <div>
      <h2>{`${category} List`}</h2>
      {data.map((item) => (
        <div key={item.id}>
          <img src={`https://image.tmdb.org/t/p/w500/${item.poster_path}`} alt={item.title || item.name} />
          <h3>{item.title || item.name}</h3>
        </div>
      ))}
    </div>
  );
}

export default List;